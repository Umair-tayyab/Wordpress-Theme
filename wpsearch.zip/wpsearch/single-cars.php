<?php get_header();?>

<!-- Main Content -->
<div class="main-container">
    <!-- Post Content -->
    <article class="post-content">
        <div class="post-image">
            <?php if(has_post_thumbnail()):?>
            <img src="<?php the_post_thumbnail_url('');?>" alt="Post Featured Image">
            <?php endif;?>
        </div>

        <h1 class="post-title"><?php the_title();?></h1>

        <div class="post-description">
            <p><?php the_content();?></p>
        </div>
        </div>
    </article>

        <?php get_footer();?>