<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Website</title>
    <?php wp_head();?>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="logo">
            <a href="<?php home_url();?>"><h2>WPSearch</h2></a>
        </div>
        <div class="hamburger">
            <div></div>
            <div></div>
            <div></div>
        </div>
        <nav>
            <ul>
                <li><a href="#">
                    <?php
                    wp_nav_menu(
                        array(
                            'theme_location' => 'header_menu',
                        )
                    );
                    ?>
                </a></li>
            </ul>
        </nav>
    </header>
    
    <!-- Overlay -->
    <div class="overlay"></div>
    