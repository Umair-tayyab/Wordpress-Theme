<?php get_header();?>
    <!-- Hero Section -->
    <section class="hero">
        <h1>Welcome to Our Website</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eget mauris vitae urna gravida maximus.</p>
        <button style="padding: 0.8rem 1.5rem; background-color: #4CAF50; color: white; border: none; border-radius: 4px; font-size: 1rem; cursor: pointer;">Learn More</button>
    </section>
<!-- Three Column Section -->
<?php 
$blog_terms = get_terms([
    'taxonomy' => 'blog',
]);

$args = [
    'post_type' => 'cars',
    'posts_per_page' => -1,
    'tax_query' => [],
    'meta_query' => [
        'relation' => 'AND',
    ],
];

if (isset($_GET['keyword']) && !empty($_GET['keyword'])) {
    $args['s'] = $_GET['keyword'];
}

if (isset($_GET['blog']) && !empty($_GET['blog'])) {
    $args['tax_query'][] = [
        'taxonomy' => 'blog',
        'field'    => 'slug',
        'terms'    => $_GET['blog'],
    ];
}

$car_query = new WP_Query($args);
?>

<section class="car-search-section">
    <div class="car-search-form">
        <form action="<?php echo home_url('/car-search'); ?>">
            <input type="text" name="keyword" placeholder="Search cars..." class="car-search-input">
            <select name="blog" class="car-search-select">
                <option value="">Choose a brand</option>
                <?php foreach($blog_terms as $blogs): ?>
                    <option value="<?php echo $blogs->slug; ?>">
                        <?php echo $blogs->name; ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="car-search-button">Search</button>
        </form>
    </div>

    <div class="car-results">
        <?php if ( $car_query->have_posts() ) : ?>
            <?php while ( $car_query->have_posts() ) : $car_query->the_post(); ?>
                <div class="car-card">
                    <div class="car-card-image">
                        <img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>">
                    </div>
                    <div class="car-card-content">
                        <h3 class="car-card-title"><?php the_title(); ?></h3>
                        <p class="car-card-excerpt"><?php the_excerpt(); ?></p>
                        <a href="<?php the_permalink(); ?>" class="car-card-link">Read More</a>
                    </div>
                </div>
            <?php endwhile; ?>
            <?php wp_reset_postdata(); ?>
        <?php else: ?>
            <p class="no-cars-found">No cars found.</p>
        <?php endif; ?>
    </div>
</section>

    
<?php get_footer();?>