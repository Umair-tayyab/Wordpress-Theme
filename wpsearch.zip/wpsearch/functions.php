<?php 

function load_stylesheet(){
    wp_register_style('stylesheet', get_template_directory_uri(). '/src/style.css', '', 1, 'all');
    wp_enqueue_style('stylesheet');
}
add_action('wp_enqueue_scripts', 'load_stylesheet');


function load_js(){
    wp_register_script('javascript', get_template_directory_uri(). '/src/app.js', array(), '1', true);
    wp_enqueue_script('javascript');
}
add_action('wp_enqueue_scripts', 'load_js');

// add Theme Support
add_theme_support('menus');
add_theme_support('post-thumbnails');


// Register Nav
register_nav_menus(
    array(
        'header_menu' => 'Header Menu',
        'footer_menu' => 'Footer Menu',
    )
);

// Register Custom Post Type
function blog_post_type(){
    $args = array(
        'labels' => array(
            'name' => 'Cars',
            'singular_name' => 'Car'
        ),
        'hierarchical' => false,
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-welcome-write-blog',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
    );
    register_post_type('cars', $args);
}
add_action('init', 'blog_post_type');

// Add Taxonomy
function blog_cate(){
    $args = array(
        'labels' => array(
            'name' => 'Blogs',
            'singular_name' => 'Blog',
        ),
        'public' => true,
        'hierarchical' => true,
    );
    register_taxonomy('blog', array('cars'), $args);
}
add_action('init', 'blog_cate');